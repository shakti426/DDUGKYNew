package com.deendayalproject.util

object AppConstant {

    const val PREF_NAME = "MyAppPreferences"
    const val TOKEN_KEY = "accessToken"
    const val STATUS_QM = "QM"
    const val STATUS_SM = "SM"

}
