package com.deendayalproject.fragments

import SharedViewModel
import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.deendayalproject.R
import com.deendayalproject.databinding.FragmentFieldVerFormBinding
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import android.view.LayoutInflater.from
import android.view.View.OnClickListener
import android.view.ViewGroup.LayoutParams
import android.view.ViewGroup.MarginLayoutParams
import android.widget.ImageView
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.navigation.fragment.findNavController
import com.deendayalproject.util.AppUtil
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * FieldVerificationFormFragment
 *
 * Shows a RecyclerView of field verification items using the layout item_field_ver_card.xml
 * This fragment includes a small local adapter so you don't need to change other files.
 *
 * If you already have your own adapter/model, you can replace `LocalFieldVerificationAdapter`
 * and `FieldVerificationItem` with your own implementations.
 */
class FieldVerificationFormFragment : Fragment() {

    private var _binding: FragmentFieldVerFormBinding? = null
    private val binding get() = _binding!!

    // Optional shared VM (attempt to obtain if present)
    private var sharedViewModel: SharedViewModel? = null

    // Recycler + Adapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var recyclerViewFin: RecyclerView

    private lateinit var recyclerViewTraining: RecyclerView

    private lateinit var recyclerViewTrainingInfra: RecyclerView

    private lateinit var recyclerViewCert: RecyclerView

    private lateinit var recyclerViewPlacement: RecyclerView

    private lateinit var recyclerViewField: RecyclerView
    //private lateinit var adapter: LocalFieldVerificationAdapter

    private lateinit var permissionLauncher: ActivityResultLauncher<String>

    private lateinit var photoUri: Uri

    private lateinit var cameraLauncher: ActivityResultLauncher<Uri>

    private var currentPhotoTarget: String = ""

    private var base64FinanceFile: String? = null

    private var base64TrainingFile: String? = null

    private var base64TrainingInfraFile: String? = null

    private var base64TrainingResFile: String? = null

    private var selectedOrganizationInfoRemarks = ""

    private var selectedFinanceRemarks = ""

    private var selectedTrainingRemarks = ""

    private var selectedTrainingInfraRemarks = ""

    private var selectedCertRemarks = ""

    private var selectedPlacementRemarks = ""

    private var selectedFieldRemarks = ""

    private var orgItems: MutableList<FieldVerificationItem> = mutableListOf()
    private var finItems: MutableList<FieldVerificationItem> = mutableListOf()

    private var trainingItems: MutableList<FieldVerificationItem> = mutableListOf()

    private var trainingInfraItems: MutableList<FieldVerificationItem> = mutableListOf()

    private var certItems: MutableList<FieldVerificationItem> = mutableListOf()

    private var placementItems: MutableList<FieldVerificationItem> = mutableListOf()

    private var fieldItems: MutableList<FieldVerificationItem> = mutableListOf()

    private var currentUploadPosition: Int = -1

    private var currentUploadList: String = ""

    private lateinit var finAdapter: LocalFieldVerificationAdapter

    private lateinit var trainingAdapter: LocalFieldVerificationAdapter

    private lateinit var trainingInfraAdapter: LocalFieldVerificationAdapter

    private lateinit var certAdapter: LocalFieldVerificationAdapter

    private lateinit var placementAdapter: LocalFieldVerificationAdapter

    private lateinit var fieldAdapter: LocalFieldVerificationAdapter

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    private var latitude: String = ""

    private var longitude: String = ""


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        _binding = FragmentFieldVerFormBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        cameraLauncher =
            registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
                if (success) {
                    Log.d("Camera", "Captured image URI: $photoUri")
                    if (currentUploadPosition >= 0) {
                        val pos = currentUploadPosition

                        when (currentUploadList) {
                            "fin" -> {
                                val existing = finItems.getOrNull(pos)
                                if (existing != null) {
                                    finItems[pos] = existing.copy(
                                        imageUri = photoUri.toString(),
                                        uploadEnabled = true
                                    )
                                    finAdapter.update(finItems)
                                }
                            }
                            "training" -> {
                                val existing = trainingItems.getOrNull(pos)
                                if (existing != null) {
                                    trainingItems[pos] = existing.copy(
                                        imageUri = photoUri.toString(),
                                        uploadEnabled = true
                                    )
                                    trainingAdapter.update(trainingItems)
                                }
                            }
                            "Training Infra" -> {
                                val existing = trainingInfraItems.getOrNull(pos)
                                if (existing != null) {
                                    trainingInfraItems[pos] = existing.copy(
                                        imageUri = photoUri.toString(),
                                        uploadEnabled = true
                                    )
                                    trainingInfraAdapter.update(trainingInfraItems)
                                }
                            }
                            else -> {
                                // default: if you still want to support orgItems, add a branch here
                            }
                        }

                        // reset flags
                        currentUploadPosition = -1
                        currentUploadList = ""
                    }
                    when (currentPhotoTarget) {

                        "Turnover" -> {
                            base64FinanceFile = AppUtil.imageUriToBase64(requireContext(), photoUri)
                        }
                        "Additional tailor-made training If Yes Upload" -> {
                            base64TrainingFile = AppUtil.imageUriToBase64(requireContext(), photoUri)
                        }
                        "Training Infrastructure" -> {
                            base64TrainingInfraFile = AppUtil.imageUriToBase64(requireContext(), photoUri)
                        }
                        "Residential Facilities" -> {
                            base64TrainingResFile = AppUtil.imageUriToBase64(requireContext(), photoUri)
                        }

                    }
                }
            }

        permissionLauncher =
            registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
                if (isGranted) launchCamera()
                else Toast.makeText(
                    requireContext(),
                    "Camera permission is required.",
                    Toast.LENGTH_SHORT
                ).show()
            }


        // Try to get shared ViewModel (if your project uses it)
        try {
            sharedViewModel = ViewModelProvider(requireActivity())[SharedViewModel::class.java]
        } catch (e: Exception) {
            sharedViewModel = null
        }

        // Set up toolbar back button
        binding.backButton.setOnClickListener {

            findNavController().navigateUp()
        }

        // Try common RecyclerView IDs to maximize compatibility with different XML variants
        recyclerView = try {
            binding.recyclerView // if binding generated this id
        } catch (e: Exception) {
            // fallback to a generic id "recyclerView" or find by id
            val rvById = view.findViewById<RecyclerView?>(R.id.recyclerView)
            rvById ?: throw IllegalStateException("RecyclerView not found. Ensure id is rv_field_ver_list or recyclerView.")
        }



        // Populate sample data (replace with your real data from ViewModel or elsewhere)
        orgItems = mutableListOf(
            FieldVerificationItem(
                requirement = resources.getString(R.string.field_ver_industry_existence),
                verificationDoc = resources.getString(R.string.field_ver_valid_govt_note_doc),
                documents = listOf(
                    "Date of Incorporation (PRN)"
                ),
                uploadEnabled = false
            ),
            FieldVerificationItem(
                requirement = resources.getString(R.string.field_ver_valid_epfo_esic_doc),
                verificationDoc = resources.getString(R.string.field_ver_valid_epfo_esic_note_doc),
                documents = listOf("EPFO", "ESIC", "Factory"),
                uploadEnabled = false
            ),
            FieldVerificationItem(
                requirement = resources.getString(R.string.field_ver_epfo_challan_doc),
                verificationDoc = resources.getString(R.string.field_ver_valid_epfo_challan_note_doc),
                documents = listOf("EPFO Challan (6 Months)", "FV"),
                uploadEnabled = false
            ),
            FieldVerificationItem(
                requirement = resources.getString(R.string.field_ver_valid_industry_doc),
                verificationDoc = resources.getString(R.string.field_ver_valid_industry_note_doc),
                documents = listOf("View"),
                uploadEnabled = false
            ),
            FieldVerificationItem(
                requirement = resources.getString(R.string.field_ver_valid_bank_doc),
                verificationDoc = resources.getString(R.string.field_ver_valid_bank_note_doc),
                documents = listOf("Account", "Aadhar Linkage"),
                uploadEnabled = false
            ),
            FieldVerificationItem(
                requirement = resources.getString(R.string.field_ver_valid_manpower_doc),
                verificationDoc = resources.getString(R.string.field_ver_valid_manpower_note_doc),
                documents = listOf("Declaration"),
                uploadEnabled = false
            )
        )
        val orgAdapter = LocalFieldVerificationAdapter(
            items = orgItems,
            onViewClick = { pos, doc ->
                Toast.makeText(requireContext(), "Position: $pos Viewing: $doc", Toast.LENGTH_SHORT).show()
                if (pos == 0 && doc=="Date of Incorporation (PRN)"){
                    val dialog = AlertDialog.Builder(requireContext())
                        .setTitle("Date of incorporation")
                        .setMessage("Date not available")
                        .setPositiveButton("OK", null)
                        .create()
                    dialog.show()
                }
            },
            onUploadClick = { _ -> /* not needed here */ },
            showIcons = true
        )
        //binding.recyclerView.adapter = orgAdapter
        // Setup adapter and layout manager

        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = orgAdapter


        orgAdapter.update(orgItems)

        //previous button finance
        binding.btnFinPrevious.setOnClickListener {

            binding.verOrg.visibility = View.VISIBLE
            binding.trainingInfraExpand.visibility = View.VISIBLE
            binding.verFin.visibility = View.GONE
            binding.verFinExpand.visibility = View.GONE

            binding.scroll.post {
                binding.scroll.smoothScrollTo(0, 0)
            }

        }

        //previous button Training
        binding.btnTrainingPrevious.setOnClickListener {

            binding.verFin.visibility = View.VISIBLE
            binding.verFinExpand.visibility = View.VISIBLE
            binding.verTraining.visibility = View.GONE
            binding.verTrainingExpand.visibility = View.GONE

            binding.scroll.post {
                binding.scroll.smoothScrollTo(0, 0)
            }

        }

        //previous button Training Infrastructure
        binding.btnTrainingInfraPrevious.setOnClickListener {

            binding.verTraining.visibility = View.VISIBLE
            binding.verTrainingExpand.visibility = View.VISIBLE
            binding.verTrainingInfra.visibility = View.GONE
            binding.verTrainingInfraExpand.visibility = View.GONE

            binding.scroll.post {
                binding.scroll.smoothScrollTo(0, 0)
            }

        }

        //previous button Assessment & Certification
        binding.btnCertPrevious.setOnClickListener {

            binding.verTrainingInfra.visibility = View.VISIBLE
            binding.verTrainingInfraExpand.visibility = View.VISIBLE
            binding.verCert.visibility = View.GONE
            binding.verCertExpand.visibility = View.GONE

            binding.scroll.post {
                binding.scroll.smoothScrollTo(0, 0)
            }

        }

        //previous button Placement
        binding.btnPlacementPrevious.setOnClickListener {

            binding.verCert.visibility = View.VISIBLE
            binding.verCertExpand.visibility = View.VISIBLE
            binding.verPlacement.visibility = View.GONE
            binding.verPlacementExpand.visibility = View.GONE

            binding.scroll.post {
                binding.scroll.smoothScrollTo(0, 0)
            }

        }

        //previous button Field Visit
        binding.btnFieldPrevious.setOnClickListener {

            binding.verPlacement.visibility = View.VISIBLE
            binding.verPlacementExpand.visibility = View.VISIBLE
            binding.verField.visibility = View.GONE
            binding.verFieldExpand.visibility = View.GONE

            binding.scroll.post {
                binding.scroll.smoothScrollTo(0, 0)
            }

        }


        // Submit button for Organisation Details : try common ids via binding or findById
        val btn = try {
            binding.btnInfoNext
        } catch (e: Exception) {
            view.findViewById<Button?>(R.id.btnInfoNext) // fallback id name
        }
        btn?.setOnClickListener {
            selectedOrganizationInfoRemarks =
                binding.etInfoRemarks.text.toString()
            if (selectedOrganizationInfoRemarks.isEmpty()) {
                Toast.makeText(
                    requireContext(),
                    "Kindly enter remarks first",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }
            // Example: collect and show a toast. Replace with actual submit logic.
            //Toast.makeText(requireContext(), "Submit clicked (items: ${orgAdapter.itemCount}) with remark "+selectedOrganizationInfoRemarks, Toast.LENGTH_SHORT).show()

            binding.trainingInfraExpand.visibility = View.GONE
            binding.tvTrainInfra.setCompoundDrawablesWithIntrinsicBounds(
                0,
                0,
                R.drawable.ic_verified,
                0
            )
            binding.verFin.visibility = View.VISIBLE
            binding.verFinExpand.visibility = View.VISIBLE
            fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity())

            // Check and request permission
            if (hasLocationPermission()) {
                getCurrentLocation()
            } else {
                requestLocationPermission()
            }
        }

        // Submit button for Finance Details

        val btnFin = try {
            binding.btnFinNext
        } catch (e: Exception) {
            view.findViewById<Button?>(R.id.btnFinNext) // fallback id name
        }
        btnFin?.setOnClickListener {
            selectedFinanceRemarks =
                binding.etFinRemarks.text.toString()
            // NEW: check required uploads for finance items
            if (!checkUploadsComplete(finItems, "Finance")) {
                // missing required photos -> do not proceed
                return@setOnClickListener
            }
            if (selectedFinanceRemarks.isEmpty()) {
                Toast.makeText(
                    requireContext(),
                    "Kindly enter remarks first",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            // Example: collect and show a toast. Replace with actual submit logic.
            //Toast.makeText(requireContext(), "Submit clicked (items: ${orgAdapter.itemCount}) with remark "+selectedFinanceRemarks, Toast.LENGTH_SHORT).show()

            binding.verFinExpand.visibility = View.GONE
            binding.tvFinHead.setCompoundDrawablesWithIntrinsicBounds(
                0,
                0,
                R.drawable.ic_verified,
                0
            )
            binding.verTraining.visibility = View.VISIBLE
            binding.verTrainingExpand.visibility = View.VISIBLE
        }

        // Optionally, if you have a SharedViewModel list available, observe it and update adapter:
        // Example (uncomment & adapt if your ViewModel has the LiveData):
        /*
        sharedViewModel?.fieldVerificationItems?.observe(viewLifecycleOwner) { list ->
            if (list != null) adapter.update(list)
        }
        */


        /* for Financial Detail */

        recyclerViewFin = try {
            binding.recyclerViewFin // if binding generated this id
        } catch (e: Exception) {
            // fallback to a generic id "recyclerView" or find by id
            val rvById = view.findViewById<RecyclerView?>(R.id.recyclerViewFin)
            rvById ?: throw IllegalStateException("RecyclerView not found. Ensure id is rv_field_ver_list or recyclerView.")
        }

        finItems = mutableListOf(
            FieldVerificationItem(
                resources.getString(R.string.field_ver_industry_turnover_fin),
                resources.getString(R.string.field_ver_industry_turnover_note_fin),
                listOf("Balance Sheet (last 3 years)"),
                uploadEnabled = false
            ),
            FieldVerificationItem(
                resources.getString(R.string.field_ver_industry_networth_fin),
                resources.getString(R.string.field_ver_industry_networth_note_fin),
                listOf("Turnover"),
                uploadEnabled = true
            )
        )

        finAdapter = LocalFieldVerificationAdapter(
            items = finItems,
            onViewClick = { _, _ -> /* not used for upload list */ },
            onUploadClick = { pos ->
                //Toast.makeText(requireContext(), "Upload clicked for item $pos", Toast.LENGTH_SHORT).show()
                // TODO: launch file picker here
                currentUploadPosition = pos
                currentUploadList = "fin"
                currentPhotoTarget = "Turnover"
                checkAndLaunchCamera()
            },
            showIcons = true
        )

        recyclerViewFin.layoutManager = LinearLayoutManager(requireContext())
        recyclerViewFin.adapter = finAdapter
        finAdapter.update(finItems)

        /* for Training Details */

        // Submit button for Training Details

        val btnTraining = try {
            binding.btnTrainingNext
        } catch (e: Exception) {
            view.findViewById<Button?>(R.id.btnTrainingNext) // fallback id name
        }
        btnTraining?.setOnClickListener {
            selectedTrainingRemarks =
                binding.etTrainingRemarks.text.toString()
            if (selectedTrainingRemarks.isEmpty()) {
                Toast.makeText(
                    requireContext(),
                    "Kindly enter remarks first",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }
            if (!checkUploadsComplete(trainingItems, "Training")) {
                // missing required photos -> do not proceed
                return@setOnClickListener
            }
            // Example: collect and show a toast. Replace with actual submit logic.
            //Toast.makeText(requireContext(), "Submit clicked (items: ${orgAdapter.itemCount}) with remark "+selectedTrainingRemarks, Toast.LENGTH_SHORT).show()

            binding.verTrainingExpand.visibility = View.GONE
            binding.tvTrainingHead.setCompoundDrawablesWithIntrinsicBounds(
                0,
                0,
                R.drawable.ic_verified,
                0
            )
            binding.verTrainingInfra.visibility = View.VISIBLE
            binding.verTrainingInfraExpand.visibility = View.VISIBLE
        }

        recyclerViewTraining = try {
            binding.recyclerViewTraining // if binding generated this id
        } catch (e: Exception) {
            // fallback to a generic id "recyclerView" or find by id
            val rvById = view.findViewById<RecyclerView?>(R.id.recyclerViewTraining)
            rvById ?: throw IllegalStateException("RecyclerView not found. Ensure id is rv_field_ver_list or recyclerView.")
        }

        trainingItems = mutableListOf(
            FieldVerificationItem(
                resources.getString(R.string.field_ver_exp_training),
                resources.getString(R.string.field_ver_exp_note_training),
                listOf("Sanction letters", "Project completion certificates", "MoUs or Work Orders with Government"),
                uploadEnabled = false
            ),
            FieldVerificationItem(
                resources.getString(R.string.field_ver_hrs_training),
                resources.getString(R.string.field_ver_hrs_note_training),
                listOf(),
                uploadEnabled = false
            ),
            FieldVerificationItem(
                resources.getString(R.string.field_ver_course_content_training),
                resources.getString(R.string.field_ver_course_content_note_training),
                listOf(),
                uploadEnabled = false
            ),
            FieldVerificationItem(
                resources.getString(R.string.field_ver_nsqf_courses_training),
                resources.getString(R.string.field_ver_nsqf_courses_note_training),
                listOf("NSQF-aligned courses"),
                uploadEnabled = false
            ),
            FieldVerificationItem(
                resources.getString(R.string.field_ver_500_cand_training),
                resources.getString(R.string.field_ver_500_cand_note_training),
                listOf("Form 1, 2"),
                uploadEnabled = false
            ),
            FieldVerificationItem(
                resources.getString(R.string.field_ver_job_training),
                resources.getString(R.string.field_ver_job_note_training),
                listOf("Additional tailor-made training If Yes Upload"),
                uploadEnabled = true
            ),
            FieldVerificationItem(
                resources.getString(R.string.field_ver_domain_training),
                resources.getString(R.string.field_ver_domain_note_training),
                listOf("Form 1, 2"),
                uploadEnabled = false
            )
        )

        trainingAdapter = LocalFieldVerificationAdapter(
            items = trainingItems,
            onViewClick = { _, _ -> /* not used for upload list */ },
            onUploadClick = { pos ->
                //Toast.makeText(requireContext(), "Upload clicked for item $pos", Toast.LENGTH_SHORT).show()
                // TODO: launch file picker here
                currentUploadPosition = pos
                currentUploadList = "training"
                currentPhotoTarget = "Additional tailor-made training If Yes Upload"
                checkAndLaunchCamera()
            },
            showIcons = true
        )

        recyclerViewTraining.layoutManager = LinearLayoutManager(requireContext())
        recyclerViewTraining.adapter = trainingAdapter
        trainingAdapter.update(trainingItems)

        /* for Training Infrastructure Details */

        // Submit button for Training Infrastructure Details

        val btnTrainingInfra = try {
            binding.btnTrainingInfraNext
        } catch (e: Exception) {
            view.findViewById<Button?>(R.id.btnTrainingInfraNext) // fallback id name
        }
        btnTrainingInfra?.setOnClickListener {
            selectedTrainingInfraRemarks =
                binding.etTrainingInfraRemarks.text.toString()
            if (selectedTrainingInfraRemarks.isEmpty()) {
                Toast.makeText(
                    requireContext(),
                    "Kindly enter remarks first",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }
            if (!checkUploadsComplete(trainingInfraItems, "Training Infrastructure")) {
                // missing required photos -> do not proceed
                return@setOnClickListener
            }
            // Example: collect and show a toast. Replace with actual submit logic.
            //Toast.makeText(requireContext(), "Submit clicked (items: ${orgAdapter.itemCount}) with remark "+selectedTrainingInfraRemarks, Toast.LENGTH_SHORT).show()

            binding.verTrainingInfraExpand.visibility = View.GONE
            binding.tvTrainingInfraHead.setCompoundDrawablesWithIntrinsicBounds(
                0,
                0,
                R.drawable.ic_verified,
                0
            )
            binding.verCert.visibility = View.VISIBLE
            binding.verCertExpand.visibility = View.VISIBLE
        }

        recyclerViewTrainingInfra = try {
            binding.recyclerViewTrainingInfra // if binding generated this id
        } catch (e: Exception) {
            // fallback to a generic id "recyclerView" or find by id
            val rvById = view.findViewById<RecyclerView?>(R.id.recyclerViewTrainingInfra)
            rvById ?: throw IllegalStateException("RecyclerView not found. Ensure id is rv_field_ver_list or recyclerView.")
        }

        trainingInfraItems = mutableListOf(
            FieldVerificationItem(
                resources.getString(R.string.field_ver_nsqf_training_infra),
                resources.getString(R.string.field_ver_nsqf_note_training_infra),
                listOf("Training Infrastructure"),
                uploadEnabled = true
            ),
            FieldVerificationItem(
                resources.getString(R.string.field_ver_res_training_infra),
                resources.getString(R.string.field_ver_res_note_training_infra),
                listOf("Residential Facilities"),
                uploadEnabled = true
            )
        )

        trainingInfraAdapter = LocalFieldVerificationAdapter(
            items = trainingInfraItems,
            onViewClick = { _, _ -> /* not used for upload list */ },
            onUploadClick = { pos ->
                //Toast.makeText(requireContext(), "Upload clicked for item $pos", Toast.LENGTH_SHORT).show()
                // TODO: launch file picker here
                currentUploadPosition = pos
                currentUploadList = "Training Infra"
                if (pos == 0)
                    currentPhotoTarget = "Training Infrastructure"
                else if (pos == 1)
                    currentPhotoTarget = "Residential Facilities"
                checkAndLaunchCamera()
            },
            showIcons = true
        )

        recyclerViewTrainingInfra.layoutManager = LinearLayoutManager(requireContext())
        recyclerViewTrainingInfra.adapter = trainingInfraAdapter
        trainingInfraAdapter.update(trainingInfraItems)


        /* for Assessment & Certification Details */

        // Submit button for Assessment & Certification Details

        val btnCert = try {
            binding.btnCertNext
        } catch (e: Exception) {
            view.findViewById<Button?>(R.id.btnCertNext) // fallback id name
        }
        btnCert?.setOnClickListener {
            selectedCertRemarks =
                binding.etCertRemarks.text.toString()
            if (selectedCertRemarks.isEmpty()) {
                Toast.makeText(
                    requireContext(),
                    "Kindly enter remarks first",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }
            // Example: collect and show a toast. Replace with actual submit logic.
            //Toast.makeText(requireContext(), "Submit clicked (items: ${certAdapter.itemCount}) with remark "+selectedCertRemarks, Toast.LENGTH_SHORT).show()

            binding.verCertExpand.visibility = View.GONE
            binding.tvCertHead.setCompoundDrawablesWithIntrinsicBounds(
                0,
                0,
                R.drawable.ic_verified,
                0
            )
            binding.verPlacement.visibility = View.VISIBLE
            binding.verPlacementExpand.visibility = View.VISIBLE
        }

        recyclerViewCert = try {
            binding.recyclerViewCert // if binding generated this id
        } catch (e: Exception) {
            // fallback to a generic id "recyclerView" or find by id
            val rvById = view.findViewById<RecyclerView?>(R.id.recyclerViewCert)
            rvById ?: throw IllegalStateException("RecyclerView not found. Ensure id is rv_field_ver_list or recyclerView.")
        }

        certItems = mutableListOf(
            FieldVerificationItem(
                resources.getString(R.string.field_ver_provide_cert),
                resources.getString(R.string.field_ver_provide_note_cert),
                listOf("Form 4"),
                uploadEnabled = false
            ),
            FieldVerificationItem(
                resources.getString(R.string.field_ver_res_conduct_cert),
                resources.getString(R.string.field_ver_conduct_note_cert),
                listOf("Form 4"),
                uploadEnabled = false
            )
        )

        certAdapter = LocalFieldVerificationAdapter(
            items = certItems,
            onViewClick = { _, _ -> /* not used for upload list */ },
            onUploadClick = { pos -> },
            showIcons = true
        )

        recyclerViewCert.layoutManager = LinearLayoutManager(requireContext())
        recyclerViewCert.adapter = certAdapter
        certAdapter.update(certItems)


        /* for Placement Details */

        // Submit button for Placement Details

        val btnPlacement = try {
            binding.btnPlacementNext
        } catch (e: Exception) {
            view.findViewById<Button?>(R.id.btnPlacementNext) // fallback id name
        }
        btnPlacement?.setOnClickListener {
            selectedPlacementRemarks =
                binding.etPlacementRemarks.text.toString()
            if (selectedPlacementRemarks.isEmpty()) {
                Toast.makeText(
                    requireContext(),
                    "Kindly enter remarks first",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }
            // Example: collect and show a toast. Replace with actual submit logic.
            //Toast.makeText(requireContext(), "Submit clicked (items: ${placementAdapter.itemCount}) with remark "+selectedPlacementRemarks, Toast.LENGTH_SHORT).show()

            binding.verPlacementExpand.visibility = View.GONE
            binding.tvPlacementHead.setCompoundDrawablesWithIntrinsicBounds(
                0,
                0,
                R.drawable.ic_verified,
                0
            )
            binding.verField.visibility = View.VISIBLE
            binding.verFieldExpand.visibility = View.VISIBLE

        }

        recyclerViewPlacement = try {
            binding.recyclerViewPlacement // if binding generated this id
        } catch (e: Exception) {
            // fallback to a generic id "recyclerView" or find by id
            val rvById = view.findViewById<RecyclerView?>(R.id.recyclerViewPlacement)
            rvById ?: throw IllegalStateException("RecyclerView not found. Ensure id is rv_field_ver_list or recyclerView.")
        }

        placementItems = mutableListOf(
            FieldVerificationItem(
                resources.getString(R.string.field_ver_500_empl_placement),
                resources.getString(R.string.field_ver_empl_note_placement),
                listOf("Sanction letters or project approval orders"),
                uploadEnabled = false
            ),
            FieldVerificationItem(
                resources.getString(R.string.field_ver_70_per_cand_placement),
                resources.getString(R.string.field_ver_empl_off_letter_note_placement),
                listOf("Form 1"),
                uploadEnabled = false
            ),
            FieldVerificationItem(
                resources.getString(R.string.field_ver_70_per_less_cand_coursewise_placement),
                resources.getString(R.string.field_ver_empl_off_letter_coursewise_less_note_placement),
                listOf("Form 1"),
                uploadEnabled = false
            ),
            FieldVerificationItem(
                resources.getString(R.string.field_ver_70_per_more_cand_coursewise_placement),
                resources.getString(R.string.field_ver_empl_off_letter_coursewise_more_note_placement),
                listOf("Form 1"),
                uploadEnabled = false
            )
        )

        placementAdapter = LocalFieldVerificationAdapter(
            items = placementItems,
            onViewClick = { _, _ -> /* not used for upload list */ },
            onUploadClick = { pos -> },
            showIcons = true
        )

        recyclerViewPlacement.layoutManager = LinearLayoutManager(requireContext())
        recyclerViewPlacement.adapter = placementAdapter
        placementAdapter.update(placementItems)

        /* for Field Visit Details */

        // Submit button for Field Visit Details

        val btnField = try {
            binding.btnFieldNext
        } catch (e: Exception) {
            view.findViewById<Button?>(R.id.btnFieldNext) // fallback id name
        }
        btnField?.setOnClickListener {
            selectedFieldRemarks =
                binding.etFieldRemarks.text.toString()
            if (selectedFieldRemarks.isEmpty()) {
                Toast.makeText(
                    requireContext(),
                    "Kindly enter remarks first",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }
            // Example: collect and show a toast. Replace with actual submit logic.
            //Toast.makeText(requireContext(), "Submit clicked (items: ${fieldAdapter.itemCount}) with remark "+selectedFieldRemarks, Toast.LENGTH_SHORT).show()

            binding.verFieldExpand.visibility = View.GONE
            binding.tvFieldHead.setCompoundDrawablesWithIntrinsicBounds(
                0,
                0,
                R.drawable.ic_verified,
                0
            )
        }

        recyclerViewField = try {
            binding.recyclerViewField // if binding generated this id
        } catch (e: Exception) {
            // fallback to a generic id "recyclerView" or find by id
            val rvById = view.findViewById<RecyclerView?>(R.id.recyclerViewField)
            rvById ?: throw IllegalStateException("RecyclerView not found. Ensure id is rv_field_ver_list or recyclerView.")
        }

        fieldItems = mutableListOf(
            FieldVerificationItem(
                resources.getString(R.string.field_ver_geo_factory_field),
                resources.getString(R.string.field_ver_ctsa_off_note_field),
                listOf("Lat: ${latitude}","Long: ${longitude}"),
                uploadEnabled = false
            )
        )

        fieldAdapter = LocalFieldVerificationAdapter(
            items = fieldItems,
            onViewClick = { _, _ -> /* not used for upload list */ },
            onUploadClick = { pos -> },
            showIcons = false
        )

        recyclerViewField.layoutManager = LinearLayoutManager(requireContext())
        recyclerViewField.adapter = fieldAdapter
        fieldAdapter.update(fieldItems)





    }

    private fun hasLocationPermission(): Boolean {
        val fineLocation = ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
        val coarseLocation = ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION)
        return fineLocation == PackageManager.PERMISSION_GRANTED ||
                coarseLocation == PackageManager.PERMISSION_GRANTED
    }

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
            val fineLocationGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
            val coarseLocationGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false

            if (fineLocationGranted || coarseLocationGranted) {
                getCurrentLocation()
            } else {
                Toast.makeText(requireContext(), "Location permission denied", Toast.LENGTH_SHORT).show()
            }
        }

    private fun requestLocationPermission() {
        requestPermissionLauncher.launch(
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        )
    }

    @SuppressLint("MissingPermission")
    private fun getCurrentLocation() {
        // Uses high accuracy priority for precise location
        fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener { location ->
                if (location != null) {
                    /*Toast.makeText(
                        requireContext(),
                        "Lat: ${location.latitude}, Lng: ${location.longitude}",
                        Toast.LENGTH_LONG
                    ).show()*/

                    latitude = location.latitude.toString()
                    longitude = location.longitude.toString()

                    if (::fieldAdapter.isInitialized) {
                        fieldItems = mutableListOf(
                            FieldVerificationItem(
                                resources.getString(R.string.field_ver_geo_factory_field),
                                resources.getString(R.string.field_ver_ctsa_off_note_field),
                                listOf("Lat: $latitude", "Long: $longitude"),
                                uploadEnabled = false
                            )
                        )
                        fieldAdapter.update(fieldItems)
                    }
                } else {
                    Toast.makeText(requireContext(), "Unable to get location", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener {
                Toast.makeText(requireContext(), "Failed to get location: ${it.message}", Toast.LENGTH_SHORT).show()
            }
    }
    private fun checkAndLaunchCamera() {
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
            launchCamera()
        else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun launchCamera() {
        val photoFile = createImageFile()
        if (photoFile == null) {
            Toast.makeText(requireContext(), "Failed to create image file", Toast.LENGTH_SHORT)
                .show()
            return
        }
        photoUri = FileProvider.getUriForFile(
            requireContext(),
            "${requireContext().packageName}.provider",
            photoFile
        )
        cameraLauncher.launch(photoUri)
    }

    private fun createImageFile(): File? {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val storageDir = requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return try {
            File.createTempFile("JPEG_${timestamp}_", ".jpg", storageDir)
        } catch (e: IOException) {
            e.printStackTrace()
            null
        }
    }

    private fun checkUploadsComplete(items: List<FieldVerificationItem>, sectionName: String = "this section"): Boolean {
        // Find items that require upload but do not have an image
        val missing = items.filter { it.uploadEnabled && it.imageUri.isNullOrBlank() }

        if (missing.isNotEmpty()) {
            // Build friendly message describing missing uploads
            val names = missing.joinToString(separator = ", ") { it.requirement.take(40) } // limit length
            val message = "Please upload photos for the items in $sectionName: $names"
            Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show()
            return false
        }

        return true
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    // ---------------------------
    // Local adapter + model below
    // ---------------------------

    // Simple data model used by the adapter. If you already have a model class, feel free to use it instead.
    data class FieldVerificationItem(
        val requirement: String,
        val verificationDoc: String,
        val documents: List<String>,
        val uploadEnabled: Boolean = false,
        val imageUri: String? = null
    )

    private inner class LocalFieldVerificationAdapter(
        private var items: List<FieldVerificationItem> = emptyList(),
        private val onViewClick: (position: Int, doc: String) -> Unit,
        private val onUploadClick: (position: Int) -> Unit,
        private val showIcons: Boolean = true

    ) : RecyclerView.Adapter<LocalFieldVerificationAdapter.VH>() {

        fun update(newItems: List<FieldVerificationItem>) {
            items = newItems
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_field_ver_card, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.tvReqTitle.text = item.requirement
            holder.tvVerification.text = item.verificationDoc

            // Clear chips then add
            holder.chipGroup.removeAllViews()
            for (doc in item.documents) {
                val chip = Chip(holder.itemView.context).apply {
                    text = doc
                    isClickable = true
                    isCheckable = false
                    if (showIcons){
                        // Show icon based on uploadEnabled flag
                        val iconRes = if (item.uploadEnabled) R.drawable.file else R.drawable.ic_up
                        closeIcon = context.getDrawable(iconRes) // 👁️ view icon
                        closeIconTint = context.getColorStateList(android.R.color.darker_gray)
                        isCloseIconVisible = true
                        iconEndPadding = 8f
                        textEndPadding = 16f
                    }else{
                        isCloseIconVisible = false
                    }

                    setOnClickListener {
                        if (item.uploadEnabled) {
                            onUploadClick(position)
                        } else {
                            onViewClick(position, doc)
                        }

                    }
                }
                holder.chipGroup.addView(chip)
            }

            if (!item.imageUri.isNullOrBlank()) {
                try {
                    holder.ivPreview?.setImageURI(Uri.parse(item.imageUri))
                    holder.ivPreview?.visibility = View.VISIBLE
                } catch (e: Exception) {
                    holder.ivPreview?.visibility = View.GONE
                }
            } else {
                holder.ivPreview?.visibility = View.GONE
            }

            /*holder.itemView.setOnClickListener {
                Toast.makeText(holder.itemView.context, item.requirement, Toast.LENGTH_SHORT).show()
            }*/
        }

        override fun getItemCount(): Int = items.size

        inner class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val tvReqTitle: TextView = itemView.findViewById(R.id.tv_req_title)
            val tvVerification: TextView = itemView.findViewById(R.id.tv_verification)
            val chipGroup: ChipGroup = itemView.findViewById(R.id.chipgroup_documents)
            val ivPreview: ImageView? = itemView.findViewById(R.id.ivPreview)
        }
    }
}
