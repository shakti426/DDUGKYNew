package com.deendayalproject.model.response

data class StateModel(val stateName: String, val stateCode: String)
