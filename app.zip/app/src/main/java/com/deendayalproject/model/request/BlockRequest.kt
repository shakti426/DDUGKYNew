package com.deendayalproject.model.request

data class BlockRequest(val appVersion: String, val districtCode: String)
