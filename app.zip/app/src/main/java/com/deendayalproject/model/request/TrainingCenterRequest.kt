package com.deendayalproject.model.request

data class TrainingCenterRequest(val appVersion: String,
                                 val loginId: String,
                                 val imeiNo: String)
