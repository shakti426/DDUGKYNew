package com.deendayalproject.model.response

data class DistrictModel(val districtName: String, val districtCode: String)
