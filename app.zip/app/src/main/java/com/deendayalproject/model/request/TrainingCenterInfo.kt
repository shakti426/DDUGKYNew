package com.deendayalproject.model.request

data class TrainingCenterInfo(val appVersion: String,
                              val loginId: String,
                              val tcId: Int,
                              val sanctionOrder: String,
                              val imeiNo: String)
