package com.deendayalproject.model.request

data class StateRequest(val appVersion: String)
