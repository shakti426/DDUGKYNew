package com.deendayalproject.model.request

data class DistrictRequest(val appVersion: String,val stateCode: String)
