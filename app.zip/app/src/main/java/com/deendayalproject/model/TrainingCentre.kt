package com.deendayalproject.model

class TrainingCentre (
        val trainingId: String,
        val trainingName: String,
        val state: String,
        val district: String,
        val shortAddress: String

)