package com.deendayalproject.model.response

data class GpModel(val gpName: String, val gpCode: String)
