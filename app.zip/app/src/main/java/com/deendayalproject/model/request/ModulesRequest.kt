package com.deendayalproject.model.request

data class ModulesRequest(val loginId: String,val appVersion: String)
