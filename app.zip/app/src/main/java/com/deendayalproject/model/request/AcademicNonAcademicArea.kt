package com.deendayalproject.model.request

data class AcademicNonAcademicArea(
    val loginId: String,
    val imeiNo: String,
    val appVersion: String,
    val tcId: String,
    val sanctionOrder: String,
)
