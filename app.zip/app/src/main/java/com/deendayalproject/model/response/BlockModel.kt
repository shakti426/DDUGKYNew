package com.deendayalproject.model.response

data class BlockModel(val blockName: String, val blockCode: String)
