package com.deendayalproject.model.request

data class GpRequest(val appVersion: String, val blockCode: String)
